package com.example.gsgur.quickeditpad;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class QuickEditPad extends AppCompatActivity {

    Button Append_Button;
    Button Replace_Button;
    Button Notify_Button;
    TextView Notes_TextView;
    EditText TextToAppend_EditText;
    Scanner scn;
    FileWriter fw;
    File QuickEditPadFile = null;
    int replace_count = 0;
    private final static int notify_ID = 48784878;
    NotificationCompat.Builder notification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quick_edit_pad);

        Append_Button = (Button)findViewById(R.id.Button_append);
        Notify_Button = (Button)findViewById(R.id.notify_Button);
        Replace_Button = (Button)findViewById(R.id.Button_replace);
        Notes_TextView = (TextView)findViewById(R.id.TextView_notes);
        TextToAppend_EditText = (EditText)findViewById(R.id.EditText_AppendText);

        notification = new NotificationCompat.Builder(this);
        notification.setAutoCancel(true);

        QuickEditPadFile = new File (getFilesDir().toString() + "/" +getString(R.string.FileName));

        if(!QuickEditPadFile.exists())
        {
            try {
                QuickEditPadFile.createNewFile();
                Toast.makeText(getApplicationContext(), "Created New file :)", Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
                Notes_TextView.append("Unable create file\n");
                Notes_TextView.append(getFilesDir().toString() + "\n");
            }
        }

        try {

            scn = new Scanner(QuickEditPadFile);

            while(scn.hasNextLine()) {
                Notes_TextView.append(scn.nextLine() + "\n");
            }

            Toast.makeText(getApplicationContext(), "Scan Complete :)", Toast.LENGTH_SHORT).show();

        } catch (IOException e)
        {
            Notes_TextView.append("Unable create scanner object");
        }

    }


    public void AppendFile (View v)
    {

        try {
            fw = new FileWriter(QuickEditPadFile);
            Notes_TextView.append("\n"+TextToAppend_EditText.getText());
            fw.append(Notes_TextView.getText().toString());
            TextToAppend_EditText.getText().clear();

        } catch(IOException e)
        {

            Toast.makeText(getApplicationContext(), "Unable to write :(", Toast.LENGTH_SHORT).show();

        } finally {
            if(fw != null)
            {
                try {
                    fw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Unable To Close File :(", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    public void ReplaceFile (View v)
    {
        if(replace_count == 2) {
            replace_count = 0;
            try {
                fw = new FileWriter(QuickEditPadFile);
                Notes_TextView.setText(TextToAppend_EditText.getText());
                fw.write(Notes_TextView.getText().toString());
                TextToAppend_EditText.getText().clear();

            } catch (IOException e) {

                Toast.makeText(getApplicationContext(), "Unable to write :(", Toast.LENGTH_SHORT).show();

            } finally {
                if (fw != null) {
                    try {
                        fw.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "Unable To Close File :(", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        } else {
            replace_count++;
            if(replace_count == 1)
                Toast.makeText(getApplicationContext(), "Press Again" + replace_count, Toast.LENGTH_SHORT).show();
        }
    }

    public void notifyMe(View v)
    {
        notification.setSmallIcon(R.drawable.ic_launcher_foreground);
        notification.setTicker("Guru Sarath");
        notification.setWhen(System.currentTimeMillis());
        notification.setContentTitle("Quick Edit Pad Memo -- ☺" );
        notification.setContentText(TextToAppend_EditText.getText());
        notification.setSubText(Notes_TextView.getText());

        Intent I = new Intent(this, QuickEditPad.class);
        PendingIntent PI = PendingIntent.getActivity(this, 0, I, PendingIntent.FLAG_UPDATE_CURRENT);
        notification.setContentIntent(PI);

        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.notify(notify_ID , notification.build());
    }


}
